<?php
@include 'config.php';
session_start();

$_SESSION;
$postID = $_GET['postID'];

if (isset($_POST['delete'])) {
  $delete = "DELETE FROM post_form WHERE id='$postID'";
  mysqli_query($conn, $delete);
  header("location:discussions.php");
}
if (isset($_POST['deletecomm'])) {
  $commID = $_POST['commID'];
  $delete = "DELETE FROM comments_form WHERE id='$commID'";
  mysqli_query($conn, $delete);
  $update = "UPDATE post_form SET comments=comments-1 WHERE id='$postID'";
  mysqli_query($conn, $update);
  header("location:discussionsthread.php?postID=$postID");
}

if (isset($_POST['submit'])) {
  if (!empty($_POST['body'])) {
    $id = $_SESSION["id"];
    $body = mysqli_real_escape_string($conn, $_POST['body']);
    if (isset($_FILES['my_image'])) {
      $img_name = $_FILES['my_image']['name'];
      $img_size = $_FILES['my_image']['size'];
      $tmp_name = $_FILES['my_image']['tmp_name'];
      $error = $_FILES['my_image']['error'];

      if ($error === 0) {
        if ($img_size > 1000000) {
          ?>
          <center>
            <p class="error"> <strong>Sorry, your file is too large.</strong></p>
            <style>
              .error {
                color: crimson;
              }
            </style>
          </center>
          <?php
        } else {
          $img_ex = pathinfo($img_name, PATHINFO_EXTENSION);
          $img_ex_lc = strtolower($img_ex);
          $allowed_exs = array("jpg", "jpeg", "png");
          if (in_array($img_ex_lc, $allowed_exs)) {
            $new_img_name = uniqid("IMG-", true) . '.' . $img_ex_lc;
            $img_upload_path = 'UPLOADS/' . $new_img_name;
            move_uploaded_file($tmp_name, $img_upload_path);
            $insert = "INSERT INTO comments_form (post_id,author_id,body,file_name) VALUES ('$postID','$id','$body','$new_img_name')";
            mysqli_query($conn, $insert);
            $update = "UPDATE post_form SET comments=comments+1 WHERE id='$postID'";
            mysqli_query($conn, $update);
            header("location:discussionsthread.php?postID=$postID");
          } else {
            ?>
            <center>
              <p class="error"> <strong>You can't upload files of this type. Only jpg, jpeg and png are allowed.</strong></p>
              <style>
                .error {
                  color: crimson;
                }
              </style>
            </center>
            <?php
          }
        }
      } elseif ($error === 4) {
        $insert = "INSERT INTO comments_form (post_id,author_id,body,file_name) VALUES ('$postID','$id','$body',0)";
        mysqli_query($conn, $insert);
        $update = "UPDATE post_form SET comments=comments+1 WHERE id='$postID'";
        mysqli_query($conn, $update);
        header("location:discussionsthread.php?postID=$postID");
      } else { ?>
        <center>
          <p class="error"> <strong>Unknown error! </strong></p>
        </center>
        <?php
      }
    } else {
      $insert = "INSERT INTO comments_form (post_id,author_id,body,file_name) VALUES ('$postID','$id','$body',0)";
      mysqli_query($conn, $insert);
      $update = "UPDATE post_form SET comments=comments+1 WHERE id='$postID'";
      mysqli_query($conn, $update);
      header("location:discussionsthread.php?postID=$postID");
    }
  } else { ?>
    <center>
      <p class="error"> <strong>Please write something! </strong></p>
      <style>
        .error {
          color: crimson;
        }
      </style>
    </center>
    <?php
  }
} ?>

<!DOCTYPE html>
<html lang="en">
<link href="style.css" rel="stylesheet" />
<title> Discussions Thread </title>

<body>

  <head>
    <a href="index.php" class="login">
      <button class="button buttonlogin">HOME</button>
    </a>
    <a href="discussions.php">
      <button class="button buttonlogin">DISCUSSIONS</button>
      <style>
        .buttonlogin {
          background: crimson;
          color: #fff;
          border-radius: 5px;
          padding: 0 15px;
          cursor: pointer;
          transition-duration: 0.5s;
        }

        .buttonlogin:hover {
          box-shadow: 0 12px 16px 0 rgb(0, 47, 255),
            0 17px 50px 0 rgba(0, 0, 0, 0.19);
        }

        .headerx {
          background: #eee;
        }
      </style>
    </a>
    <?php
    if (isset($_SESSION['name'])) {
      $userID = $_SESSION['id']; ?>
      <a href="user_profile.php?userID=<?php echo $userID ?>">
        <button class="button buttonlogin">MY PROFILE</button>
      </a>
    <?php } ?>
  </head>
  <center>
    <div class="header">
      <h1 class="title">
        <?php $select = "SELECT * FROM post_form WHERE id='$postID'";
        $result = mysqli_query($conn, $select);
        $row = mysqli_fetch_array($result);
        $file_name = $row['file_name'];
        ?>
        <p class="postbody">
          <?php echo $row['title']; ?>
        </p>
      </h1>
      <h3>
        <p class="postbody">
          <?php echo $row['body']; ?>
        </p>
        <style>
          .postbody {
            overflow-wrap: break-word;
          }
        </style>
      </h3>
      <?php if ($file_name !== '0') {
        ?>
        <center>
          <div class="picture">
            <img src="UPLOADS/<?php echo $file_name ?>" onclick="enlarge()" id="img">
            <style>
              .picture {
                width: 800px;
                height: 500px;
              }

              .picture img {
                width: 100%;
                height: 100%;
              }
            </style>
            <script>
              santinela = 1;
              function enlarge() {
                santinela = santinela * -1;
                img = document.getElementById("img");
                if (santinela === -1) {
                  img.style.transform = "scale(1.5)";
                  img.style.transition = "transform 0.25s ease";
                }
                else {
                  img.style.transform = "scale(1)";
                  img.style.transition = "transform 0.25 ease";
                }
              }
            </script>
          </div>
        </center>
        </br>
        <?php
      } ?>
      <div class="bottom">
        <p class="timestamp">
          <?php $nume = "SELECT * FROM user_form WHERE id=$row[author_id]";
          $res = mysqli_query($conn, $nume);
          $numex = mysqli_fetch_array($res);
          $userID = $numex['id'];
          ?>
          <a href="user_profile.php?userID=<?php echo $userID ?>">
            <?php echo $numex['name']; ?>
          </a>- <?php
          echo $row['date'] ?>
        </p>
        <p class="comment-count">
          <?php echo $row['comments'];
          if ($row['comments'] == 1) {
            ?> comment <?php } else { ?> comments <?php } ?>
        </p>
      </div>
      <style>
        .delete {
          background: crimson;
          -webkit-text-fill-color: #fff;
          border-radius: 5px;
          padding: 0 15px;
          cursor: pointer;
          transition-duration: 0.5s;
        }

        .delete:hover {
          box-shadow: 0 12px 16px 0 rgb(0, 47, 255),
            0 17px 50px 0 rgba(0, 0, 0, 0.19);
        }
      </style>
      <?php if (isset($_SESSION['user_type']) && ($_SESSION['user_type'] === 'admin' || $_SESSION['id'] === $row['author_id'])) { ?>
        <form action="" method="post">
          <input type="submit" value="DELETE POST" name="delete" class="delete">
        </form>
        </br>
      <?php } ?>
    </div>
    <?php if (isset($_SESSION['name'])) { ?>
      <form action="" method="post" enctype="multipart/form-data">
        <textarea class="body" minlength="10" rows="4" cols="50" type="text" name="body" id="body"></textarea>
        <br>
        <input type="file" name="my_image">
        <input type="submit" name="submit" value="ADD COMMENT" class="button buttonlogin">
        </br></br>
      </form>
      <?php
    } ?>
    <?php $sql = "SELECT * FROM comments_form WHERE post_ID='$postID' ORDER BY date DESC";
    $result = mysqli_query($conn, $sql);
    if (mysqli_num_rows($result) > 0) {
      while ($row = mysqli_fetch_assoc($result)) {
        $filex_name = $row['file_name'];
        $select = "SELECT * FROM user_form WHERE id='$row[author_id]'";
        $res = mysqli_query($conn, $select);
        $name = mysqli_fetch_array($res);
        $userID = $name['id'];
        ?>
        <center>
          <div class="comment">
            <p class="user">
              </br>
              <a href="user_profile.php?userID=<?php echo $userID ?>">
                <?php
                echo $name['name'];
                ?>
              </a><?php
              echo " - ";
              echo $row['date'] ?>
            </p>
            <div class="comment-content">
              <center></br>
                <?php echo $row['body'];
                ?>
              </center>
            </div>
            <div class="box">
              <?php if ($filex_name !== '0') {
                ?></br><img src="UPLOADS/<?php echo $filex_name ?>"></br>
                <style>
                  .box img {
                    width: 100%;
                    height: auto;
                  }
                </style>
              </div></br>
              <?php
              }
              if (isset($_SESSION['user_type']) && ($_SESSION['user_type'] === 'admin' || $_SESSION['id'] === $row['author_id'])) {
                $commID = $row['id'];
                ?></br>
              <form action="discussionsthread.php?postID=<?php echo $postID ?>" method="post">
                <input type="hidden" name="commID" value="<?php echo $commID; ?> ">
                <input class="delete" type="submit" id="deletecomm" name="deletecomm" value="DELETE COMMENT">
              </form>
            <?php } ?>
            <style>
              a {
                color: black;
                transition-duration: 0.5s;
              }

              a:hover {
                color: rgb(0, 47, 255);
              }
            </style>
          </div>
        </center>
        </br>
        <?php
      }
    } ?>
  </center>
  <style>
    .comment {
      width: 1200px;
      overflow-wrap: break-word;
      font-size: 20px;
      -webkit-text-fill-color: black;
      border: 1px solid crimson;
      border-radius: 25px;
      background: radial-gradient(rgba(80, 80, 80, 0.3), #eee);
    }

    textarea {
      width: 1200px;
      resize: none;
      font-size: 25px;
    }

    h1 {
      font-size: 50px;
    }

    body {
      background-color: #eee;
    }

    .header {
      font-size: 25px;
      -webkit-text-fill-color: black;
    }

    .comment-content {
      overflow-wrap: break-word;
      width: 800px;
    }

    .add_comment {
      -webkit-text-fill-color: black;
    }

    a {
      color: black;
      transition-duration: 0.5s;
    }

    a:hover {
      color: rgb(0, 47, 255);
    }
  </style>
</body>

</html>