<?php

@include 'config.php';
session_start();
$_SESSION;
if (isset($_POST['submit'])) {
    if (!empty($_POST['title']) && !empty($_POST['body'])) {
        $id = $_SESSION["id"];
        $title = mysqli_real_escape_string($conn, $_POST['title']);
        $body = mysqli_real_escape_string($conn, $_POST['body']);
        if (isset($_FILES['my_image']) && !empty($_FILES['my_image'])) {
            echo "<pre>";
            print_r($_FILES['my_image']);
            echo "</pre>";

            $img_name = $_FILES['my_image']['name'];
            $img_size = $_FILES['my_image']['size'];
            $tmp_name = $_FILES['my_image']['tmp_name'];
            $error = $_FILES['my_image']['error'];

            if ($error === 0) {
                if ($img_size > 1000000) {
                    $em = "Sorry, your file is too large.";
                    header("location:marketplace_post.php?error=$em");
                } else {
                    $img_ex = pathinfo($img_name, PATHINFO_EXTENSION);
                    $img_ex_lc = strtolower($img_ex);
                    $allowed_exs = array("jpg", "jpeg", "png");
                    if (in_array($img_ex_lc, $allowed_exs)) {
                        $new_img_name = uniqid("IMG-", true) . '.' . $img_ex_lc;
                        $img_upload_path = 'UPLOADS/' . $new_img_name;
                        move_uploaded_file($tmp_name, $img_upload_path);
                        $insert = "INSERT INTO post_form (topic,comments,author_id,title,body,file_name) VALUES ('marketplace', 0, '$id','$title','$body','$new_img_name')";
                        mysqli_query($conn, $insert);
                        header('location:marketplace.php');
                    } else {
                        $em = "You can't upload files of this type. Only jpg, jpeg and png are allowed.";
                        header("location:marketplace_post.php?error=$em");
                    }
                }
            } elseif ($error === 4) {
                $insert = "INSERT INTO post_form (topic,comments,author_id,title,body,file_name) VALUES ('marketplace', 0, '$id','$title','$body',0)";
                mysqli_query($conn, $insert);
                header('location:marketplace.php');
            } else {
                $em = "Unknown error occured!";
                header("location:marketplace_post.php?error=$em");
            }
        } else {
            $insert = "INSERT INTO post_form (topic,comments,author_id,title,body,file_name) VALUES ('marketplace', 0, '$id','$title','$body',0)";
            mysqli_query($conn, $insert);
            header('location:marketplace.php');
        }

    } else {
        $em = "Please write something!";
        header("location:marketplace_post.php?error=$em");
    }
}
?>

<!DOCTYPE html>
<html>
<meta charset="UTF-8" />
<meta name="viewport" content="width=device-width, initial-scale=1.0" />
<link href="style.css" rel="stylesheet" />
<script src="https://use.fontawesome.com/3a2eaf6206.js"></script>
<title> Market Place Post </title>

<head>
    <a href="index.php" class="login">
        <button class="button buttonlogin">HOME</button>
    </a>
    <a href="marketplace.php">
        <button class="button buttonlogin">MARKET PLACE</button>
        <style>
            .buttonlogin {
                background: crimson;
                color: #fff;
                border-radius: 5px;
                padding: 0 15px;
                cursor: pointer;
                transition-duration: 0.5s;
            }

            .buttonlogin:hover {
                box-shadow: 0 12px 16px 0 rgb(0, 47, 255),
                    0 17px 50px 0 rgba(0, 0, 0, 0.19);
            }

            .headerx {
                background: #eee;
            }
        </style>
    </a>
    <?php $userID = $_SESSION['id']; ?>
    <a href="user_profile.php?userID=<?php echo $userID ?>">
        <button class="button buttonlogin">MY PROFILE </button>
    </a>
</head>

<center>

    <body>
        <?php if (isset($_GET['error'])) { ?>
            <p class="err"><?php echo $_GET['error'];
        } ?><style>
                .err {
                    color: crimson;
                    font-weight: bold;
                }
            </style>
        </p>
        <form action="" method="post" enctype="multipart/form-data">
            <label for="title">Title:</label>
            <input class="title" minlength="10" maxlength="100" type="text" name="title" id="title">
            </br></br>
            <label for="body">Body:</label>
            <textarea class="body" minlength="10" rows="4" cols="50" type="text" name="body" id="body"></textarea>
            </br>
            <input type="file" name="my_image">
            <style>
                div {
                    width: 13%;
                    text-align: center;
                    padding: 3%;
                    border: thin solid black;
                }

                label {
                    cursor: pointer;
                }
            </style>
            <input type="submit" name="submit" value="SUBMIT" class="button buttonlogin">
            <style>
                .title {
                    width: 50%;
                    height: 30px;
                    padding: 12px 20px;
                    box-sizing: border-box;
                    border: 2px solid #ccc;
                    border-radius: 4px;
                    background-color: #f8f8f8;
                }

                .body {
                    width: 75%;
                    height: 100px;
                    padding: 12px 20px;
                    box-sizing: border-box;
                    border: 2px solid #ccc;
                    border-radius: 4px;
                    background-color: #f8f8f8;
                }
            </style>
    </body>
</center>

</html>