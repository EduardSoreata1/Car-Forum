<?php

session_start();

@include 'config.php';
$userID = $_GET['userID'];

$_SESSION;
?>

<!DOCTYPE html>
<html>
<meta charset="UTF-8" />
<meta name="viewport" content="width=device-width, initial-scale=1.0" />
<link href="style.css" rel="stylesheet" />
<script src="https://use.fontawesome.com/3a2eaf6206.js"></script>
<title> User Profile </title>

<head>
    <a href="index.php" class="login">
        <button class="button buttonlogin">HOME</button>
    </a>
    <style>
        .buttonlogin {
            background: crimson;
            color: #fff;
            border-radius: 5px;
            padding: 0 15px;
            cursor: pointer;
            transition-duration: 0.5s;
        }

        .buttonlogin:hover {
            box-shadow: 0 12px 16px 0 rgb(0, 47, 255),
                0 17px 50px 0 rgba(0, 0, 0, 0.19);
        }

        body {
            background-color: #eee;
        }
    </style>
</head>

<body>
    <h1>
        <div class="posts">
            <?php $sql = "SELECT * FROM user_form WHERE id='$userID'";
            $result = mysqli_query($conn, $sql);
            $name = mysqli_fetch_array($result);
            $letter = $name['name'];
            $letter = $letter[-1];
            if ($letter === 's') {
                echo trim($name['name']);
                echo "' posts:";
            } else {
                echo trim($name['name']);
                echo "'s posts:";
            }
            ?>
            <center>
                <div>
                    <?php $sql = "SELECT * FROM post_form WHERE author_id='$userID' ORDER BY date DESC";
                    $result = mysqli_query($conn, $sql);
                    if (mysqli_num_rows($result) > 0) {
                        while ($row = mysqli_fetch_assoc($result)) {
                            $file_name = $row['file_name'];
                            $postID = $row['id'];
                            ?>
                            <div class="postare">
                                <?php if ($row['topic'] === 'discussions') { ?><a
                                        href="discussionsthread.php?postID=<?php echo $postID; ?>">
                                    <?php } ?>
                                    <?php if ($row['topic'] === 'marketplace') { ?><a
                                            href="marketplacethread.php?postID=<?php echo $postID; ?>">
                                        <?php } ?>
                                        <?php if ($row['topic'] === 'events') { ?><a
                                                href="eventsthread.php?postID=<?php echo $postID; ?>">
                                            <?php } ?>

                                            <h4 class="title">
                                                <?php echo $row['title'] ?>
                                                <style>
                                                    .title {
                                                        overflow-wrap: break-word;
                                                    }

                                                    a {
                                                        color: black;
                                                        transition-duration: 0.5s;
                                                    }

                                                    a:hover {
                                                        color: rgb(0, 47, 255);
                                                    }
                                                </style>
                                        </a>
                                        <?php if ($file_name !== '0') {
                                            ?>
                                            <div class="picture">
                                                <img src="UPLOADS/<?php echo $file_name ?>" style=”width:800px;> </br>
                                            </div>
                                            <?php
                                        } ?>
                                        <div>
                                            <?php echo $row['comments'];
                                            if ($row['comments'] === 1)
                                                echo " comment - ";
                                            else
                                                echo " comments - ";
                                            echo $row['date'];
                                            ?>
                                        </div>
                            </div>
                            </br>
                            <?php
                        }
                    }
                    ?>
                    </br></br>
            </center>
        </div>
        <div class="comments">
            <?php
            if ($letter === 's') {
                echo trim($name['name']);
                echo "' comments:";
            } else {
                echo trim($name['name']);
                echo "'s comments:";
            }
            ?>
            <center>
                <?php
                $sql = "SELECT * FROM comments_form WHERE author_id='$userID' ORDER BY date DESC";
                $result = mysqli_query($conn, $sql);
                if (mysqli_num_rows($result) > 0) {
                    while ($row = mysqli_fetch_assoc($result)) {
                        $file_name = $row['file_name'];
                        $postID = $row['post_id'];
                        $sqlx = "SELECT * FROM post_form WHERE id='$postID'";
                        $res = mysqli_query($conn, $sqlx);
                        $topicx = mysqli_fetch_array($res);
                        $topic = $topicx['topic'];
                        ?>
                        <div class="postare">
                            <?php if ($topic === 'discussions') { ?><a
                                    href="discussionsthread.php?postID=<?php echo $postID; ?>">
                                <?php } ?>
                                <?php if ($topic === 'marketplace') { ?><a
                                        href="marketplacethread.php?postID=<?php echo $postID; ?>">
                                    <?php } ?>
                                    <?php if ($topic === 'events') { ?><a href="eventsthread.php?postID=<?php echo $postID; ?>">
                                        <?php } ?>

                                        <h4 class="title">
                                            <?php echo $row['body'] ?>
                                            <style>
                                                .title {
                                                    overflow-wrap: break-word;
                                                }

                                                a {
                                                    color: black;
                                                    transition-duration: 0.5s;
                                                }

                                                a:hover {
                                                    color: rgb(0, 47, 255);
                                                }
                                            </style>
                                    </a>
                                    <div class="box">
                                        <?php if ($file_name !== '0') {
                                            ?></br><img src="UPLOADS/<?php echo $file_name ?>"></br>
                                            <style>
                                                .box img {
                                                    width: 100%;
                                                    height: auto;
                                                }
                                            </style>
                                        </div></br>
                                        <?php
                                        } ?>
                                    <div>
                                        <?php echo $row['date']; ?>
                                    </div>
                        </div>
                        </br>
                        <?php
                    }
                } ?>
                <?php
                ?>
        </div>
        </center>
    </h1>
</body>
<style>
    .postare {
        width: 1200px;
        overflow-wrap: break-word;
        font-size: 20px;
        -webkit-text-fill-color: black;
        border: 1px solid crimson;
        border-radius: 25px;
        background: radial-gradient(rgba(80, 80, 80, 0.2), #eee);
    }
</style>

</html>