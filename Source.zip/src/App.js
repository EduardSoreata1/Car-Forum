import logo from './logo.svg';
import './App.css';

function App() {
  return (
    <div className="App">
    <head>
        <meta charset = "UTF-8"></meta>
        <meta name = "description" content = "Cars and everything related!"></meta>
        <title>
            COSH
        </title>
    </head>
    <body>
        <h1>
            <i> Cars: Our Second Home! </i>
        </h1>
        <span>
            <button class = "bg-blue-450 hover:bg-blue-700 text-white font-bold py-2 px-6 border border-blue-700 rounded">
                <a href = "discussions.html"> Discussions </a>
            </button>
        </span>
        <span>
            <button class = "bg-blue-500 hover:bg-blue-700 text-white font-bold py-2 px-4 border border-blue-700 rounded">
                <a href = "marketplace.html"> Market Place </a>
            </button>
        </span>
        <span>
            <button class = "bg-blue-500 hover:bg-blue-700 text-white font-bold py-2 px-4 border border-blue-700 rounded">
                <a href = "events.html"> Events </a>
            </button>
        </span>
    </body>
    </div>
  );
}

export default App;
