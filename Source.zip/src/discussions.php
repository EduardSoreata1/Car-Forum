<?php

session_start();

@include 'config.php';

$_SESSION;
?>

<!DOCTYPE html>
<html>

<head>
  <meta charset="UTF-8" />
  <title>Discussions</title>
  <link href="style.css" rel="stylesheet" />
  <style>
    h1 {
      -webkit-text-fill-color: rgb(110, 10, 10);
    }

    h2 {
      font-size: xx-large;
      -webkit-text-fill-color: crimson;
    }

    body {
      background-color: #eee;
    }
  </style>
</head>

<body>
  <div class="headerx">
    <a href="index.php" class="login">
      <button class="button buttonlogin">HOME</button>
      <?php if (isset($_SESSION['name'])) { ?>
        <a href="discussions_post.php" class="login">
          <button class="button buttonlogin">NEW POST</button>
        </a>
        <?php $userID = $_SESSION['id']; ?>
        <a href="user_profile.php?userID=<?php echo $userID ?>">
          <button class="button buttonlogin">MY PROFILE </button>
        </a>
      <?php }
      ?>
      <style>
        .buttonlogin {
          background: crimson;
          color: #fff;
          border-radius: 5px;
          padding: 0 15px;
          cursor: pointer;
          transition-duration: 0.5s;
        }

        .buttonlogin:hover {
          box-shadow: 0 12px 16px 0 rgb(0, 47, 255),
            0 17px 50px 0 rgba(0, 0, 0, 0.19);
        }

        .headerx {
          background: #eee;
        }
      </style>
    </a>
  </div>
  <div class="top-bar">
    <h2>Discussions</h2>
  </div>
  <center>
    <div class="main">
      <ol>
        <?php
        $sql = "SELECT id,author_id, comments, title,file_name,date FROM post_form WHERE topic='discussions' ORDER BY date DESC";
        $result = mysqli_query($conn, $sql);
        if (mysqli_num_rows($result) > 0) {
          while ($row = mysqli_fetch_assoc($result)) {
            $author_id = $row["author_id"];
            $file_name = $row["file_name"];
            $namex = "SELECT * FROM user_form WHERE id = '$author_id'";
            $namey = mysqli_query($conn, $namex);
            $name = mysqli_fetch_array($namey);
            $postID = $row['id'];
            ?>
            <div class="postare">
              <a href="discussionsthread.php?postID=<?php echo $postID; ?>">
                <h4 class="title">
                  <?php echo $row['title'] ?>
                  <style>
                    a {
                      color: black;
                      transition-duration: 0.5s;
                    }

                    a:hover {
                      color: rgb(0, 47, 255);
                    }
                  </style>
              </a>
              </br>
              <?php if ($file_name !== '0') {
                ?>
                <div class="picture">
                  <img src="UPLOADS/<?php echo $file_name ?>" style=”width:800px;>
                </div>
                <?php
              }
              $userID = $author_id;
              ?><a href="user_profile.php?userID=<?php echo $userID; ?>">
                <?php echo $name['name'] ?>
              </a>
              -
              <?php echo $row['date'] ?>
              </br>
              </h4>
              <div class="bottom">
                <p class="comment-count">
                  <?php echo $row['comments'];
                  if ($row['comments'] == 1) { ?> comment <?php } else { ?>
                    comments <?php } ?>
                </p>
              </div>
            </div>
            </br>
            <?php
          }
        }
        ?>
      </ol>
    </div>
  </center>
  <style>
    .title {
      overflow-wrap: break-word;
    }

    .postare {
      border: 2px solid crimson;
      border-radius: 25px;
      background: radial-gradient(rgba(80, 80, 80, 0.3), #eee);
    }

    .main {
      background: radial-gradient(rgba(80, 80, 80, 0.1), #eee);
      padding: 10px 15px;
    }

    body {
      margin: 50px;
    }

    h4 {
      margin: 0;
      font-size: xx-large;
    }

    p {
      margin: 1px 0;
    }

    .top-bar {
      text-align: center;
      background-color: #eee;
    }

    .row {
      padding: 15px 0;
      font-size: xx-large;
    }

    .bottom {
      -webkit-text-fill-color: black;
      font-size: 25px;
    }

    .timestamp {
      padding-right: 10px;
    }
  </style>
</body>

</html>