var threads =[
    {
        title: "Thread 1",
        author: "Soreata",
        date: Date.now(),
        content: "Thread content",
        comments: [
            {
                author: "Stefan",
                date: Date.now(),
                content:"Hey there!"
            },
            {
                author: "Eduard",
                date: Date.now(),
                content: "Hey, you!"
            }
        ]
    },
    {
        title: "Thread 2",
        author: "Sory",
        date: Date.now(),
        content: "Thread content",
        comments: [
            {
                author: "Stef",
                date: Date.now(),
                content:"Hey there!"
            },
            {
                author: "Edu",
                date: Date.now(),
                content: "Hey, you!"
            }
        ]
    }
]