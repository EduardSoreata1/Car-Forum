<?php

session_start();

$_SESSION;

?>

<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scae=1.0" />
  <meta name="description" content="Cars and everything related!" />
  <title>COSH</title>
  <link href="style.css" rel="stylesheet" />
  <style>
    .buttonx {
      height: 400px;
      width: 400px;
      background-size: 100% 100%;
      text-align: center;
      text-decoration: none;
      display: inline-block;
      font-size: 50px;
      margin: 1px 0.5px;
      transition-duration: 0.5s;
      cursor: pointer;
      padding: 75px;
      border-radius: 50%;
      -webkit-text-fill-color: crimson;
      -webkit-text-stroke-width: 1.5px;
      -webkit-text-stroke-color: rgb(0, 0, 0);
    }

    .buttonx:hover {
      color: white;
      box-shadow: 0 12px 16px 0 rgb(0, 47, 255),
        0 17px 50px 0 rgba(0, 0, 0, 0.19);
    }

    .button1 {
      background: url("images/DISCUSSIONS.jpg") no-repeat;
    }

    .button2 {
      background: url("images/MARKETPLACE.webp") no-repeat;
    }

    .button3 {
      background: url("images/EVENTS.jpg") no-repeat;
    }

    .buttonlogin {
      background: crimson;
      color: #fff;
      border-radius: 5px;
      padding: 0 15px;
      cursor: pointer;
      transition-duration: 0.5s;
    }

    .buttonlogin:hover {
      box-shadow: 0 12px 16px 0 rgb(0, 47, 255),
        0 17px 50px 0 rgba(0, 0, 0, 0.19);
    }
  </style>
  <?php
  if (!isset($_SESSION['name'])) {
    ?>
    <a href="login_form.php" class="login">
      <button class="button buttonlogin">LOGIN</button>
    </a>
    <a href="register_form.php">
      <button class="button buttonlogin">REGISTER</button>
    </a>
    <?php
  } else { ?>
    <a href="logout.php">
      <button class="button buttonlogin">LOGOUT</button>
    </a>
    <?php $userID = $_SESSION['id']; ?>
    <a href="user_profile.php?userID=<?php echo $userID ?>">
      <button class="button buttonlogin">MY PROFILE </button>
    </a>
    <?php
  } ?>
</head>
<style>
  html {
    background: url(images/xxxxxxx.jpg) no-repeat center center fixed;
    -webkit-background-size: cover;
    -moz-background-size: cover;
    -o-background-size: cover;
    background-size: cover;
  }
</style>
<style>
  h1 {
    font-style: normal;
    font-size: 100px;
    text-align: center;
    -webkit-text-stroke: 1px rgb(255, 255, 255);
    -webkit-text-fill-color: rgb(0, 47, 255);
  }
</style>

<body>
  <h1>Cars: Our Second Home!</h1>
  <span class="discussions">
    <style>
      .discussions {
        float: left;
        margin-top: 30px;
        margin-left: 50px;
      }
    </style>
    <a href="discussions.php">
      <button class="buttonx button1">Discussions</button>
    </a>
  </span>
  <span class="marketplace">
    <style>
      .marketplace {
        float: left;
        margin-top: 30px;
        margin-left: 110px;
      }
    </style>
    <a href="marketplace.php">
      <button class="buttonx button2">Market Place</button>
    </a>
  </span>
  <span class="events">
    <style>
      .events {
        float: right;
        margin-top: 30px;
        margin-right: 50px;
      }
    </style>
    <a href="events.php">
      <button class="buttonx button3">Events</button>
    </a>
  </span>
</body>

</html>